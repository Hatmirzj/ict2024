import grpc
import greet_pb2
import greet_pb2_grpc
# Connect to the gRPC server and call the SayHello method
def run():
    # Connect to the server on port 50051
    with grpc.insecure_channel('localhost:50051') as channel:
        stub = greet_pb2_grpc.GreeterStub(channel)
        
        # Create a HelloRequest message and call the SayHello method
        name = "ICTUser"
        request = greet_pb2.HelloRequest(name=name)
        response = stub.SayHello(request)
     
        # Print the response
        print("Client received:", response.message)
if __name__ == '__main__':
    run()
