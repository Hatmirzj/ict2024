from concurrent import futures
import grpc
import greet_pb2
import greet_pb2_grpc
# Define the Greeter service by extending the generated GreeterServicer
class Greeter(greet_pb2_grpc.GreeterServicer):
    # Implement the SayHello method
    def SayHello(self, request, context):
        name = request.name
        message = f"Hello, {name}!"
        return greet_pb2.HelloReply(message=message)
# Start the gRPC server
def serve():
    server = grpc.server(futures.ThreadPoolExecutor(max_workers=10))
    greet_pb2_grpc.add_GreeterServicer_to_server(Greeter(), server)
    server.add_insecure_port('[::]:50051')
    server.start()
    print("Server is running on port 50051...")
    server.wait_for_termination()
if __name__ == '__main__':
    serve()
