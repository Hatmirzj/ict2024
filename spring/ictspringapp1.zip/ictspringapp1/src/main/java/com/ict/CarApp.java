package com.ict;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.ict.beans.Employee;
import com.ict.beans.Engine;
import com.ict.beans.Parking;
public class CarApp 
{  // static Engine engine;
    public static void main( String[] args )
    {   /*
    	engine=new Engine();
        engine.milage();
        
        Engine e1=new Engine();
        e1.milage();
        */
    	Employee emp=new Employee();
    	System.out.println(emp);
    	AnnotationConfigApplicationContext context = 
    			new AnnotationConfigApplicationContext(SpringConfig.class);
    	Engine e=(Engine)context.getBean(Engine.class);	
        System.out.println(e);
         Parking  p=(Parking)context.getBean(Parking.class);	
   	 	System.out.println(p.getAmount());
     	System.out.println(p);
     	Employee emp1=(Employee)context.getBean(Employee.class);
     			System.out.println(emp1);
  
    	context.close();
   }
}
