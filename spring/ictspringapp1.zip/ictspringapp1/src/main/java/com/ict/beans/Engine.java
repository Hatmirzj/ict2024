package com.ict.beans;

import org.springframework.stereotype.Component;

@Component
public class Engine {

	  void milage() {
		  System.out.println("Milage is 80KMPH");
	  }
	
	
}
