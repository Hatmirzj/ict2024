package com.ict;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Scope;

import com.ict.beans.Engine;
import com.ict.beans.Parking;
//beans.xml
@Configuration
@ComponentScan("com.ict.beans")
public class SpringConfig {
	
}
