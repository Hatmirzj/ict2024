package com.ict.beans;

import org.springframework.stereotype.Component;

@Component
public class Parking {
	
	double amount;
	
	Parking(){
		amount=999.99;
	}
	public double getAmount() {
		return amount;
	}

}
