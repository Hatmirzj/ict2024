package com.ict.sbwebapp1;

import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController   //@Component
public class HelloController {
	@GetMapping("/welcome")
	public String getMessage() {
		return "Welcome to RestController, SpringBoot Web App";
	}
	@GetMapping("/welcome/{name}")
	public String getMessage1(@PathVariable("name") String name) {
		return "Welcome  MRs/Mrs/Miss:"+name;
	}
	@PostMapping("/add")
	public String  addMEssage() {
		return " Added successfully";
	}
	@PutMapping("/update")
	public String  updateMEssage() {
		return " update successfully....+++++++++++.....";
	}
	@DeleteMapping("/delete")
	public String  deleteMEssage() {
		return " delete successfully..++++++++++++.......";
	}
	
	
}
