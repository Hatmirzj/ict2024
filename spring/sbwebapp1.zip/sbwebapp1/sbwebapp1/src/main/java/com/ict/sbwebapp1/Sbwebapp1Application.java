package com.ict.sbwebapp1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Sbwebapp1Application {

	public static void main(String[] args) {
		SpringApplication.run(Sbwebapp1Application.class, args);
	}

}
