from prometheus_client import start_http_server, Gauge
import random
import time

# Create a Prometheus gauge metric
TEMPERATURE = Gauge('room_temperature_celsius', 'Temperature of the room in Celsius')

def generate_random_metrics():
    while True:
        # Generate a random temperature value
        temperature = random.uniform(15.0, 30.0)
        TEMPERATURE.set(temperature)
        print(f"Generated temperature: {temperature:.2f}°C")
        time.sleep(2)

if __name__ == "__main__":
    # Start the Prometheus metrics server on port 8000
    start_http_server(8000)
    print("Prometheus metrics server started at http://localhost:8000/metrics")
    generate_random_metrics()
