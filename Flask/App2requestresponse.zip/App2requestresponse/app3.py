
from flask import Flask 
  
app = Flask(__name__) 
  
@app.route('/user/<username>') 
def show_user(username): 
    # Greet the user 
    return f'Hello {username} !'
  
# Pass the required route to the decorator. 
@app.route("/hello") 
def hello(): 
    return "Hello, Welcome to Flask tutorial"
    
@app.route("/") 
def index(): 
    return "Homepage of Flask"
  
if __name__ == "__main__": 
    app.run(debug=True)