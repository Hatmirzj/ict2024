from flask import Flask                  #pip install flask
app = Flask(__name__)

@app.route('/')
def hello():
    return '<h1>Welcome to VENV app</h1>'

 
if __name__ == '__main__':
    app.run()
