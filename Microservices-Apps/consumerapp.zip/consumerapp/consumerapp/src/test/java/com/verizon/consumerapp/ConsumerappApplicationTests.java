package com.verizon.consumerapp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ConsumerappApplicationTests {

	@Test
	void contextLoads() {
	}

}
