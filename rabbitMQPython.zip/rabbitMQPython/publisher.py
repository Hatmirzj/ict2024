from rabbitmq import RabbitMQ

rabbitmq = RabbitMQ()
message = 'Test message welcome to ICT training: python'

rabbitmq.publish("test-queue",message)
print(f"Sent message: {message}")
rabbitmq.close()