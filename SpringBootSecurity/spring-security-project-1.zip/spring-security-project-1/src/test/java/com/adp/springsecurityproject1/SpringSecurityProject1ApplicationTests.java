package com.adp.springsecurityproject1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringSecurityProject1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
