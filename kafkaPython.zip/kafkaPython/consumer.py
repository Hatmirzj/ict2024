from kafka import KafkaConsumer
import json

# Create Kafka consumer
consumer = KafkaConsumer(
    'pythontopic',
    bootstrap_servers='localhost:9092',
    auto_offset_reset='earliest',
    group_id='test-consumer-group',
    value_deserializer=lambda v: json.loads(v.decode('utf-8')),
   api_version=(0, 10, 1)

)

# Start listening for messages
print("Listening for messages...")
for message in consumer:
    print(f"Received: {message.value}")

