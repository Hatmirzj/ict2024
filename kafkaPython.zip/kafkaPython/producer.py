from kafka import KafkaProducer
import json
import time

# Create Kafka producer
producer = KafkaProducer(
    bootstrap_servers='localhost:9092',
    value_serializer=lambda v: json.dumps(v).encode('utf-8'),
     api_version=(0, 10, 1)
    
)

# Send messages to Kafka
for i in range(5):
    message = {'number': i, 'message': f'Hello Kafka {i}'}
    producer.send('pythontopic', value=message)
    print(f"Sent: {message}")
    time.sleep(1)  # Wait 1 second between messages

# Close the producer
producer.close()

