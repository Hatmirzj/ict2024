from datetime import datetime
from elasticsearch import Elasticsearch

# Connect to the Elasticsearch cluster
client = Elasticsearch("http://localhost:9200")

# Index a document
doc = {
    'author': 'author_name',
    'text': 'Interesting content...',
    'timestamp': datetime.now(),
}
response = client.index(index="test-index", id=1, document=doc)
print(response['result'])

# Retrieve the document
response = client.get(index="test-index", id=1)
print(response['_source'])

# Refresh the index
client.indices.refresh(index="test-index")

# Search for the document
response = client.search(index="test-index", query={"match_all": {}})
print("Got %d Hits:" % response['hits']['total']['value'])
for hit in response['hits']['hits']:
    print("%(timestamp)s %(author)s: %(text)s" % hit["_source"])